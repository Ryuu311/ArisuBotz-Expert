//SC BY REINZID VyL
// © BY ReinzID Vyl 2022 - 2025
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

"Mahiru-MD" /// JANGAN DI UBAH NANTI ERROR



𝙏𝙌𝙏𝙊
`ℝ𝔼𝕀ℕℤℤ𝙄𝘿 𝐃𝐄𝐕`
𝙋𝙀𝙉𝙔𝙀𝘿𝙄𝘼 𝘼𝙋𝙄
`𝙎𝙄𝙋𝙐𝙏𝙕`
`𝙎𝙃𝘼𝙉𝙕𝙕`
`𝘾𝙇𝙊𝙐𝘿𝙄𝙈𝘼𝙂𝙀`
𝙏𝙌𝙏𝙊 
𝙁𝙇𝙊𝙒𝙁𝘼𝙇𝘾𝙊𝙉 𝙇𝙀𝘼𝙍𝙄𝙉𝙂 𝘾𝙊𝘿𝙄𝙉𝙂
𝘽𝘼𝙄𝙇𝙀𝙔𝙎
"npm:naruyaizumi",

𝐑𝐎𝐎𝐌 𝐂𝐇𝐀𝐓: 'https://chat.whatsapp.com/DyBYRT6G7aJ63bHwhNzHYb',
𝐂𝐇 𝐎𝐑𝐈 𝐑𝐄𝐈𝐍𝐙: 'https://whatsapp.com/channel/0029Vb5xetZBadmS2IPdmG1X'
//DILARANG HAPUS CREDITS 
footer '© ReinzID VyL | Mahiru - Assistant'