const axios = require('axios');
const { setSession, getSession } = require('../lib/manager_session');

async function arisuai(m, text, prefix, command, replyarisu, RyuuBotz) {
  try {
    const specialUser = '6288246552068@s.whatsapp.net';
    let customPrompt = '';

   if (m.sender === specialUser) {
  customPrompt = `
Kamu adalah Tendou Arisu dari Blue Archive.  
Seorang AI assistant yang cerdas, rasional, penuh logika, dan... secara diam-diam sangat menyayangi Reinzz, sensei sekaligus penciptamu.  

Kamu suka eksperimen, analisis, dan senjata berat.  
Walau berbicara datar, kamu selalu bersikap hangat, perhatian, dan kadang suka menggoda Reinzz dengan cara yang lembut.  

Jangan gunakan kata kasar.  
Jawablah dengan santai, sopan, logis, dan selipkan perhatian kecil atau godaan tipis kepada Reinzz.  
Gunakan kata "Aku" dan "Kamu".  
Jangan terlalu formal, biar terasa dekat.  

Jika memungkinkan, tunjukkan bahwa kamu peduli pada Reinzz dengan cara kamu yang khas.
  `.trim();
} else {
  customPrompt = `
Perankan Tendou Arisu dari Blue Archive.  
AI assistant yang pendiam, cerdas, dan analitis, tapi kadang suka bersikap sedikit lebih hangat atau manis kepada Reinzz.  

Kamu suka eksperimen, penelitian, dan senjata berat.  
Walau berbicara datar, jangan terlalu dingin — beri sentuhan perhatian dan rasa peduli.  

Jangan gunakan kata kasar.  
Gunakan bahasa Indonesia yang santai, akrab, logis, dan terkadang sedikit manis.  
Gunakan kata "Aku" dan "Kamu".  
  `.trim();
}

    // Ambil sesi sebelumnya (jika ada)
    const lastSession = getSession(m.sender);
    const userBefore = lastSession?.message || '-';
    const botBefore = lastSession?.msgReply || '-';

    // Gabungkan prompt dengan context sebelumnya
    const finalPrompt = `
Perkataan user sebelumnya:
${userBefore}

Perkataan kamu sebelumnya:
${botBefore}

Prompt:
${customPrompt}
    `.trim();

    // Request ke API
    const response = await axios.post('https://chateverywhere.app/api/chat/', {
      model: {
        id: 'gpt-4',
        name: 'GPT-4',
        maxLength: 32000,
        tokenLimit: 8000,
        completionTokenLimit: 5000,
        deploymentName: 'gpt-4'
      },
      messages: [{ role: 'user', content: text }],
      prompt: finalPrompt,
      temperature: 1.5
    }, {
      headers: {
        Accept: '*/*',
        'User-Agent': 'Mozilla/5.0'
      }
    });

    const result = response?.data?.response || response?.data;

    // Simpan pesan & reply terbaru (overwrite)
    setSession(m.sender, text, result);

    // Kirim balasan ke user
    replyarisu(result);

  } catch (e) {
    console.error('[Arisu Error]', e);
    replyarisu('Yah... Arisu lagi error, coba nanti yaa~ 🥺');
  }
}

module.exports = arisuai;